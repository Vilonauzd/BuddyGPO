﻿####################################################
## BuddyGPO_CreateWinRM.ps1      ##################
## v0.12 - By jm@cloudware.host  ###################
###################################################

# Import required modules
Import-Module GroupPolicy

# Define GPO name and domain
$GPOName = "Enable WinRM"
$DomainName = (Get-ADDomain).DistinguishedName
##########################################################
### Update this line to reflect your domain or OUT #######
##########################################################
$OUPath = "DC=DOMAIN,DC=COM"  # Modify as needed

# Create the GPO if it doesn't exist
if (-not (Get-GPO -Name $GPOName -ErrorAction SilentlyContinue)) {
    New-GPO -Name $GPOName | Out-Null
    Write-Host "GPO '$GPOName' created successfully."
} else {
    Write-Host "GPO '$GPOName' already exists."
}

# Configure WinRM Service Settings
$WinRMSettings = @(
    @{ Path = "Computer Configuration\Policies\Administrative Templates\Windows Components\Windows Remote Management (WinRM)\WinRM Service"; Name = "Allow remote server management through WinRM"; State = "Enabled" }
    @{ Path = "Computer Configuration\Policies\Administrative Templates\Windows Components\Windows Remote Management (WinRM)\WinRM Client"; Name = "Allow unencrypted traffic"; State = "Enabled" }
    @{ Path = "Computer Configuration\Policies\Administrative Templates\Windows Components\Windows Remote Management (WinRM)\WinRM Client"; Name = "Trusted Hosts"; State = "Enabled"; Value = "*" }  # Adjust as needed
)

# Apply GPO settings
foreach ($Setting in $WinRMSettings) {
    Set-GPRegistryValue -Name $GPOName -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\$($Setting.Name)" -Type String -Value $Setting.State
    Write-Host "Configured '$($Setting.Name)' in '$GPOName'."
}

# Configure Windows Firewall to Allow WinRM
Set-GPRegistryValue -Name $GPOName -Key "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\AuthorizedApplications\List" -ValueName "%SystemRoot%\System32\svchost.exe" -Type String -Value "TCP:5985:*:Enabled:WinRM"

# Link the GPO to the domain or a specific OU
New-GPLink -Name $GPOName -Target $OUPath -Enforced Yes

# Apply policy to "Domain Computers" security group
$GroupName = "Domain Computers"
Set-GPPermission -Name $GPOName -PermissionLevel GpoApply -TargetName $GroupName -TargetType Group

Write-Host "GPO '$GPOName' linked to '$OUPath' and applied to '$GroupName'."

# Force Group Policy update silently on all domain computers
Write-Host "Forcing Group Policy update silently..."
Invoke-Command -ScriptBlock { gpupdate /force /quiet } -ComputerName (Get-ADComputer -Filter * | Select-Object -ExpandProperty Name) -AsJob

Write-Host "WinRM GPO configuration completed successfully!"
