﻿######################################################################
## BuddyGPO_CreateWinRM_PreReq_WinFirewall.ps1      ##################
## v0.12 - By jm@cloudware.host                    ###################
######################################################################
# Import required modules
Import-Module GroupPolicy

# Define GPO name and domain
$GPOName = "Allow WinRM Windows Firewall"
$DomainName = (Get-ADDomain).DistinguishedName

##########################################################
### Update this line to reflect your domain or OUT #######
##########################################################
$OUPath = "DC=DOMAIN,DC=COM"  # Modify as needed

# Create the GPO if it doesn't exist
if (-not (Get-GPO -Name $GPOName -ErrorAction SilentlyContinue)) {
    New-GPO -Name $GPOName | Out-Null
    Write-Host "GPO '$GPOName' created successfully."
} else {
    Write-Host "GPO '$GPOName' already exists."
}

# Define Firewall Rules Path in GPO
$FirewallPath = "Computer Configuration\Policies\Windows Settings\Security Settings\Windows Defender Firewall with Advanced Security\Windows Defender Firewall with Advanced Security\Inbound Rules"

# Add Firewall Rules for WinRM (Ports 5985 and 5986)
$WinRMFirewallRules = @(
    @{ Name = "Allow WinRM HTTP (TCP 5985)"; Port = 5985; Protocol = "TCP"; Action = "Allow" }
    @{ Name = "Allow WinRM HTTPS (TCP 5986)"; Port = 5986; Protocol = "TCP"; Action = "Allow" }
)

# Apply Firewall Rules
foreach ($Rule in $WinRMFirewallRules) {
    Set-GPRegistryValue -Name $GPOName -Key "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules" -ValueName "$($Rule.Name)" -Type String -Value "v2.10|Action=$($Rule.Action)|Active=TRUE|Dir=In|Protocol=$($Rule.Protocol)|LPort=$($Rule.Port)|RA4=*" 
    Write-Host "Configured firewall rule: $($Rule.Name) in '$GPOName'."
}

# Link the GPO to the domain or a specific OU
New-GPLink -Name $GPOName -Target $OUPath -Enforced Yes

# Apply policy to "Domain Computers" security group
$GroupName = "Domain Computers"
Set-GPPermission -Name $GPOName -PermissionLevel GpoApply -TargetName $GroupName -TargetType Group

Write-Host "GPO '$GPOName' linked to '$OUPath' and applied to '$GroupName'."

# Force Group Policy update silently on all domain computers
Write-Host "Forcing Group Policy update silently..."
Invoke-Command -ScriptBlock { gpupdate /force /quiet } -ComputerName (Get-ADComputer -Filter * | Select-Object -ExpandProperty Name) -AsJob

Write-Host "Firewall GPO for WinRM configured successfully!"
