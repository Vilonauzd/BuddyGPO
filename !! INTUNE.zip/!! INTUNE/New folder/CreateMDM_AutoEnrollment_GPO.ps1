﻿#######################################################
## BuddyGPO_CreateGPO_MDMAutoEnroll.psl        ########
## v0.12 - By jm@cloudware.host               #########
#######################################################

# Import Group Policy module
Import-Module GroupPolicy

# Define Variables
$GPOName = "MDM Auto Enrollment"
$DomainName = (Get-ADDomain).DistinguishedName
##########################################################
### Update this line to reflect your domain or OUT #######
##########################################################
$OUPath = "DC=DOMAIN,DC=COM"  # Modify as needed
$GroupName = "Domain Users"

# Create the GPO if it doesn't exist
if (-not (Get-GPO -Name $GPOName -ErrorAction SilentlyContinue)) {
    New-GPO -Name $GPOName | Out-Null
    Write-Host "GPO '$GPOName' created successfully."
} else {
    Write-Host "GPO '$GPOName' already exists."
}

# Configure MDM Auto Enrollment Policy
$MDMPath = "Software\Policies\Microsoft\Windows\CurrentVersion\MDM"
$RegistrySettings = @(
    @{ Name = "AutoEnrollMDM"; Type = "DWord"; Value = 1 }
    @{ Name = "UseAADCredential"; Type = "DWord"; Value = 1 }
)

# Apply registry settings using LGPO.exe (Local Group Policy Object Utility)
$GPO = Get-GPO -Name $GPOName
foreach ($Setting in $RegistrySettings) {
    Set-GPRegistryValue -Name $GPOName -Key "HKLM\$MDMPath" -ValueName $Setting.Name -Type $Setting.Type -Value $Setting.Value
    Write-Host "Configured $($Setting.Name) in '$GPOName'."
}

# Link the GPO to the domain root or a specific OU
New-GPLink -Name $GPOName -Target $OUPath -Enforced Yes

# Set Security Filtering to apply only to Domain Users
$GroupDN = Get-ADGroup -Identity $GroupName | Select-Object -ExpandProperty DistinguishedName
Set-GPPermission -Name $GPOName -PermissionLevel GpoApply -TargetName $GroupName -TargetType Group
Write-Host "GPO linked to '$OUPath' and applied to '$GroupName'."

# Force Group Policy update on all clients
Write-Host "Forcing group policy update on all domain computers..."
Invoke-Command -ScriptBlock { gpupdate /force } -ComputerName (Get-ADComputer -Filter * | Select-Object -ExpandProperty Name)

Write-Host "GPO configuration completed successfully!"
