﻿####################################################
## BuddyGPO_CreateGPO_HybridJoin.psl        ########
## v0.12 - By jm@cloudware.host               ######
####################################################
## Import required modules
Import-Module GroupPolicy

# Define GPO name and domain details
$GPOName = "Azure Hybrid Join Policy - Updated"
$DomainName = (Get-ADDomain).DistinguishedName
##########################################################
### Update this line to reflect your domain or OUT #######
##########################################################
$OUPath = "DC=DOMAIN,DC=COM"  # Modify as needed

# Create the GPO if it doesn't exist
if (-not (Get-GPO -Name $GPOName -ErrorAction SilentlyContinue)) {
    New-GPO -Name $GPOName | Out-Null
    Write-Host "GPO '$GPOName' created successfully."
} else {
    Write-Host "GPO '$GPOName' already exists."
}

# Define Registry Path for Device Registration
$DeviceRegPath = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WorkplaceJoin"

# Define Required Registry Settings
$HybridJoinSettings = @(
    @{ Name = "AutoWorkplaceJoin"; Type = "DWord"; Value = 1 }
    @{ Name = "WamDefaultSetTenant"; Type = "String"; Value = "yes" }
)

# Apply Registry Settings in GPO
foreach ($Setting in $HybridJoinSettings) {
    Set-GPRegistryValue -Name $GPOName -Key $DeviceRegPath -ValueName $Setting.Name -Type $Setting.Type -Value $Setting.Value
    Write-Host "Configured '$($Setting.Name)' in '$GPOName'."
}

# Configure Group Policy Setting for Device Registration
$DeviceRegistrationPolicyPath = "Computer Configuration\Policies\Administrative Templates\Windows Components\Device Registration"
Set-GPRegistryValue -Name $GPOName -Key "HKLM\SOFTWARE\Policies\Microsoft\Windows\Device Registration" -ValueName "EnableDeviceRegistration" -Type DWord -Value 1
Write-Host "Enabled 'Device Registration' in '$GPOName'."

# Link the GPO to the domain or specific OU
New-GPLink -Name $GPOName -Target $OUPath -Enforced Yes

# Apply policy to "Domain Computers" security group
$GroupName = "Domain Computers"
Set-GPPermission -Name $GPOName -PermissionLevel GpoApply -TargetName $GroupName -TargetType Group

Write-Host "GPO '$GPOName' linked to '$OUPath' and applied to '$GroupName'."

# Force Group Policy update silently on all domain computers
Write-Host "Forcing Group Policy update silently..."
Invoke-Command -ScriptBlock { gpupdate /force /quiet } -ComputerName (Get-ADComputer -Filter * | Select-Object -ExpandProperty Name) -AsJob

Write-Host "Azure Hybrid Join Policy GPO configured successfully!"
